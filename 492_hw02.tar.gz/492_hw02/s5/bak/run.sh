#!/bin/bash

#### Source stuff
. ./cmd.sh
. ./path.sh


# Copy text data
paste -d ' '  ${hw2_dir}/etc/pizza_devel.fileids ${hw2_dir}/etc/pizza_devel.transcription > data/text || exit 0

# Prepare wav.scp indicating location of wavefiles
for file in ${hw2_dir}/wav/*; do fname=$(basename "$file" .wav); echo $fname $file; done > data/wav.scp || exit 0

# Some other files
cut -d ' ' -f 1 data/text > utterances.train  || exit 0
cp utterances.train speakers.train || exit 0
paste utterances.train speakers.train > data/utt2spk || exit 0
./utils/utt2spk_to_spk2utt.pl data/utt2spk > data/spk2utt || exit 0

# Ensure that everything is ok
./utils/fix_data_dir.sh data/ || exit 0

#### Extract features. They are called mfcc
steps/make_mfcc.sh --mfcc-config conf/mfcc.conf --nj 16 --cmd "run.pl" data/ exp/mfcc mfcc || exit 0
steps/compute_cmvn_stats.sh data/ exp/mfcc mfcc/ || exit 0
 
# Decode using pretrained acoustic models
steps/decode.sh --config conf/decode.config --nj 16 --cmd "run.pl" exp/tri2b/graph data/ exp/tri2b/decode || exit 0

echo "SUCCESS"
