f = open('lexicon.txt','r+')
phone = []
count = 0
line = f.readline()
while line:
    count+=1
    print(count)
    tmp = line
    print(tmp.strip('\n'))
    split = tmp.strip('\n').split()
    print(split)
    for i in split:
        print(split.index(i))
        if split.index(i)>0:
            if i not in phone:
                phone.append(i)
    line = f.readline()
f.close()
print(phone)

new = open('phone.txt','w+')
for i in phone:
    new.writelines(i+'\n')
new.close()
