#!/bin/bash
cd /export/a15/mhwu/kaldi-trunk/egs/rm/s5
. ./path.sh
( echo '#' Running on `hostname`
  echo '#' Started at `date`
  echo -n '# '; cat <<EOF
gmm-acc-stats-ali exp/tri2a/3.mdl "ark,s,cs:apply-cmvn  --utt2spk=ark:data/train/split8/$SGE_TASK_ID/utt2spk scp:data/train/split8/$SGE_TASK_ID/cmvn.scp scp:data/train/split8/$SGE_TASK_ID/feats.scp ark:- | add-deltas ark:- ark:- |" "ark,s,cs:gunzip -c exp/tri2a/ali.$SGE_TASK_ID.gz|" exp/tri2a/3.$SGE_TASK_ID.acc 
EOF
) >exp/tri2a/log/acc.3.$SGE_TASK_ID.log
time1=`date +"%s"`
 ( gmm-acc-stats-ali exp/tri2a/3.mdl "ark,s,cs:apply-cmvn  --utt2spk=ark:data/train/split8/$SGE_TASK_ID/utt2spk scp:data/train/split8/$SGE_TASK_ID/cmvn.scp scp:data/train/split8/$SGE_TASK_ID/feats.scp ark:- | add-deltas ark:- ark:- |" "ark,s,cs:gunzip -c exp/tri2a/ali.$SGE_TASK_ID.gz|" exp/tri2a/3.$SGE_TASK_ID.acc  ) 2>>exp/tri2a/log/acc.3.$SGE_TASK_ID.log >>exp/tri2a/log/acc.3.$SGE_TASK_ID.log
ret=$?
time2=`date +"%s"`
echo '#' Accounting: time=$(($time2-$time1)) threads=1 >>exp/tri2a/log/acc.3.$SGE_TASK_ID.log
echo '#' Finished at `date` with status $ret >>exp/tri2a/log/acc.3.$SGE_TASK_ID.log
[ $ret -eq 137 ] && exit 100;
touch exp/tri2a/q/done.383.$SGE_TASK_ID
exit $[$ret ? 1 : 0]
## submitted with:
# qsub -S /bin/bash -v PATH -cwd -j y -o exp/tri2a/q/acc.3.log -l arch=*64  -t 1:8 /export/a15/mhwu/kaldi-trunk/egs/rm/s5/exp/tri2a/q/acc.3.sh >>exp/tri2a/q/acc.3.log 2>&1
