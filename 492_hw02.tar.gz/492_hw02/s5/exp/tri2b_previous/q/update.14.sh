#!/bin/bash
cd /export/a15/mhwu/kaldi-trunk/egs/rm/s5
. ./path.sh
( echo '#' Running on `hostname`
  echo '#' Started at `date`
  echo -n '# '; cat <<EOF
gmm-est --mix-up=5544 --power=0.25 --write-occs=exp/tri2a/15.occs exp/tri2a/14.mdl "gmm-sum-accs - exp/tri2a/14.*.acc |" exp/tri2a/15.mdl 
EOF
) >exp/tri2a/log/update.14.log
time1=`date +"%s"`
 ( gmm-est --mix-up=5544 --power=0.25 --write-occs=exp/tri2a/15.occs exp/tri2a/14.mdl "gmm-sum-accs - exp/tri2a/14.*.acc |" exp/tri2a/15.mdl  ) 2>>exp/tri2a/log/update.14.log >>exp/tri2a/log/update.14.log
ret=$?
time2=`date +"%s"`
echo '#' Accounting: time=$(($time2-$time1)) threads=1 >>exp/tri2a/log/update.14.log
echo '#' Finished at `date` with status $ret >>exp/tri2a/log/update.14.log
[ $ret -eq 137 ] && exit 100;
touch exp/tri2a/q/done.1469
exit $[$ret ? 1 : 0]
## submitted with:
# qsub -S /bin/bash -v PATH -cwd -j y -o exp/tri2a/q/update.14.log -l arch=*64   /export/a15/mhwu/kaldi-trunk/egs/rm/s5/exp/tri2a/q/update.14.sh >>exp/tri2a/q/update.14.log 2>&1
