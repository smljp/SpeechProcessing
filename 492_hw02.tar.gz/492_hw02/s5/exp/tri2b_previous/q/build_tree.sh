#!/bin/bash
cd /export/a15/mhwu/kaldi-trunk/egs/rm/s5
. ./path.sh
( echo '#' Running on `hostname`
  echo '#' Started at `date`
  echo -n '# '; cat <<EOF
build-tree --verbose=1 --max-leaves=1800 --cluster-thresh=-1 exp/tri2a/treeacc data/lang/phones/roots.int exp/tri2a/questions.qst data/lang/topo exp/tri2a/tree 
EOF
) >exp/tri2a/log/build_tree.log
time1=`date +"%s"`
 ( build-tree --verbose=1 --max-leaves=1800 --cluster-thresh=-1 exp/tri2a/treeacc data/lang/phones/roots.int exp/tri2a/questions.qst data/lang/topo exp/tri2a/tree  ) 2>>exp/tri2a/log/build_tree.log >>exp/tri2a/log/build_tree.log
ret=$?
time2=`date +"%s"`
echo '#' Accounting: time=$(($time2-$time1)) threads=1 >>exp/tri2a/log/build_tree.log
echo '#' Finished at `date` with status $ret >>exp/tri2a/log/build_tree.log
[ $ret -eq 137 ] && exit 100;
touch exp/tri2a/q/done.31992
exit $[$ret ? 1 : 0]
## submitted with:
# qsub -S /bin/bash -v PATH -cwd -j y -o exp/tri2a/q/build_tree.log -l arch=*64   /export/a15/mhwu/kaldi-trunk/egs/rm/s5/exp/tri2a/q/build_tree.sh >>exp/tri2a/q/build_tree.log 2>&1
