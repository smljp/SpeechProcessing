#!/bin/bash
cd /export/a15/mhwu/kaldi-trunk/egs/rm/s5
. ./path.sh
( echo '#' Running on `hostname`
  echo '#' Started at `date`
  echo -n '# '; cat <<EOF
gmm-latgen-faster --max-active=7000 --beam=20.0 --lattice-beam=10.0 --acoustic-scale=0.083333 --allow-partial=true --word-symbol-table=exp/tri2a/graph/words.txt exp/tri2a/final.mdl exp/tri2a/graph/HCLG.fst "ark,s,cs:apply-cmvn  --utt2spk=ark:data/test/split20/$SGE_TASK_ID/utt2spk scp:data/test/split20/$SGE_TASK_ID/cmvn.scp scp:data/test/split20/$SGE_TASK_ID/feats.scp ark:- | add-deltas ark:- ark:- |" "ark:|gzip -c > exp/tri2a/decode/lat.$SGE_TASK_ID.gz" 
EOF
) >exp/tri2a/decode/log/decode.$SGE_TASK_ID.log
time1=`date +"%s"`
 ( gmm-latgen-faster --max-active=7000 --beam=20.0 --lattice-beam=10.0 --acoustic-scale=0.083333 --allow-partial=true --word-symbol-table=exp/tri2a/graph/words.txt exp/tri2a/final.mdl exp/tri2a/graph/HCLG.fst "ark,s,cs:apply-cmvn  --utt2spk=ark:data/test/split20/$SGE_TASK_ID/utt2spk scp:data/test/split20/$SGE_TASK_ID/cmvn.scp scp:data/test/split20/$SGE_TASK_ID/feats.scp ark:- | add-deltas ark:- ark:- |" "ark:|gzip -c > exp/tri2a/decode/lat.$SGE_TASK_ID.gz"  ) 2>>exp/tri2a/decode/log/decode.$SGE_TASK_ID.log >>exp/tri2a/decode/log/decode.$SGE_TASK_ID.log
ret=$?
time2=`date +"%s"`
echo '#' Accounting: time=$(($time2-$time1)) threads=1 >>exp/tri2a/decode/log/decode.$SGE_TASK_ID.log
echo '#' Finished at `date` with status $ret >>exp/tri2a/decode/log/decode.$SGE_TASK_ID.log
[ $ret -eq 137 ] && exit 100;
touch exp/tri2a/decode/q/done.4939.$SGE_TASK_ID
exit $[$ret ? 1 : 0]
## submitted with:
# qsub -S /bin/bash -v PATH -cwd -j y -o exp/tri2a/decode/q/decode.log -l arch=*64  -t 1:20 /export/a15/mhwu/kaldi-trunk/egs/rm/s5/exp/tri2a/decode/q/decode.sh >>exp/tri2a/decode/q/decode.log 2>&1
