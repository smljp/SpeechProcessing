#!/bin/bash
cd /export/a15/mhwu/kaldi-trunk/egs/rm/s5
. ./path.sh
( echo '#' Running on `hostname`
  echo '#' Started at `date`
  echo -n '# '; cat <<EOF
cat exp/tri2a/decode/scoring/$SGE_TASK_ID.tra | utils/int2sym.pl -f 2- exp/tri2a/graph/words.txt | sed s:\<UNK\>::g | compute-wer --text --mode=present ark:data/test/text ark,p:- >& exp/tri2a/decode/wer_$SGE_TASK_ID 
EOF
) >exp/tri2a/decode/scoring/log/score.$SGE_TASK_ID.log
time1=`date +"%s"`
 ( cat exp/tri2a/decode/scoring/$SGE_TASK_ID.tra | utils/int2sym.pl -f 2- exp/tri2a/graph/words.txt | sed s:\<UNK\>::g | compute-wer --text --mode=present ark:data/test/text ark,p:- >& exp/tri2a/decode/wer_$SGE_TASK_ID  ) 2>>exp/tri2a/decode/scoring/log/score.$SGE_TASK_ID.log >>exp/tri2a/decode/scoring/log/score.$SGE_TASK_ID.log
ret=$?
time2=`date +"%s"`
echo '#' Accounting: time=$(($time2-$time1)) threads=1 >>exp/tri2a/decode/scoring/log/score.$SGE_TASK_ID.log
echo '#' Finished at `date` with status $ret >>exp/tri2a/decode/scoring/log/score.$SGE_TASK_ID.log
[ $ret -eq 137 ] && exit 100;
touch exp/tri2a/decode/scoring/q/done.5346.$SGE_TASK_ID
exit $[$ret ? 1 : 0]
## submitted with:
# qsub -S /bin/bash -v PATH -cwd -j y -o exp/tri2a/decode/scoring/q/score.log -l arch=*64  -t 2:13 /export/a15/mhwu/kaldi-trunk/egs/rm/s5/exp/tri2a/decode/scoring/q/score.sh >>exp/tri2a/decode/scoring/q/score.log 2>&1
