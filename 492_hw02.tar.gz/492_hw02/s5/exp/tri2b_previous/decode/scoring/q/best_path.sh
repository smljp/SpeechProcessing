#!/bin/bash
cd /export/a15/mhwu/kaldi-trunk/egs/rm/s5
. ./path.sh
( echo '#' Running on `hostname`
  echo '#' Started at `date`
  echo -n '# '; cat <<EOF
lattice-scale --inv-acoustic-scale=$SGE_TASK_ID "ark:gunzip -c exp/tri2a/decode/lat.*.gz|" ark:- | lattice-add-penalty --word-ins-penalty=0.0 ark:- ark:- | lattice-best-path --word-symbol-table=exp/tri2a/graph/words.txt ark:- ark,t:exp/tri2a/decode/scoring/$SGE_TASK_ID.tra 
EOF
) >exp/tri2a/decode/scoring/log/best_path.$SGE_TASK_ID.log
time1=`date +"%s"`
 ( lattice-scale --inv-acoustic-scale=$SGE_TASK_ID "ark:gunzip -c exp/tri2a/decode/lat.*.gz|" ark:- | lattice-add-penalty --word-ins-penalty=0.0 ark:- ark:- | lattice-best-path --word-symbol-table=exp/tri2a/graph/words.txt ark:- ark,t:exp/tri2a/decode/scoring/$SGE_TASK_ID.tra  ) 2>>exp/tri2a/decode/scoring/log/best_path.$SGE_TASK_ID.log >>exp/tri2a/decode/scoring/log/best_path.$SGE_TASK_ID.log
ret=$?
time2=`date +"%s"`
echo '#' Accounting: time=$(($time2-$time1)) threads=1 >>exp/tri2a/decode/scoring/log/best_path.$SGE_TASK_ID.log
echo '#' Finished at `date` with status $ret >>exp/tri2a/decode/scoring/log/best_path.$SGE_TASK_ID.log
[ $ret -eq 137 ] && exit 100;
touch exp/tri2a/decode/scoring/q/done.5267.$SGE_TASK_ID
exit $[$ret ? 1 : 0]
## submitted with:
# qsub -S /bin/bash -v PATH -cwd -j y -o exp/tri2a/decode/scoring/q/best_path.log -l arch=*64  -t 2:13 /export/a15/mhwu/kaldi-trunk/egs/rm/s5/exp/tri2a/decode/scoring/q/best_path.sh >>exp/tri2a/decode/scoring/q/best_path.log 2>&1
