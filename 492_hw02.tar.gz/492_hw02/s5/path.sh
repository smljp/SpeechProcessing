export KALDI_ROOT=/mnt/e/UCAS/CMU/11-492_Speech_Processing/HW2/Kaldi_toolkit/kaldi
[ -f $KALDI_ROOT/tools/env.sh ] && . $KALDI_ROOT/tools/env.sh
export PATH=$PWD/utils/:$KALDI_ROOT/tools/openfst/bin:$PWD:$PATH:$KALDI_ROOT/tools/sph2pipe_v2.5
[ ! -f $KALDI_ROOT/tools/config/common_path.sh ] && echo >&2 "The standard file $KALDI_ROOT/tools/config/common_path.sh is not present -> Exit!" && exit 1
. $KALDI_ROOT/tools/config/common_path.sh

# Enable SRILM
#. $KALDI_ROOT/tools/env.sh
export LC_ALL=C

export hw2_dir=/mnt/e/UCAS/CMU/11-492_Speech_Processing/HW2/hw02_asr/