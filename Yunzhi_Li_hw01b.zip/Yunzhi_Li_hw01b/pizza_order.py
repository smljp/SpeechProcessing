import logging
from flask import Flask, render_template
from flask_ask import Ask, statement, question, session

app = Flask(__name__)
ask = Ask(app, "/")
logging.getLogger("flask_ask").setLevel(logging.DEBUG)


@ask.launch
def welcome():
    session.attributes['state']=0
    session.attributes['discount']=0
    welcome_msg = render_template('welcome')
    return question(welcome_msg)

@ask.intent("TrackOrderIntent")
def track_order():
    track_msg = "Currently, you have no order. Would you like to start a new order?"
    return question(track_msg)

@ask.intent("YesIntent")
def response_yes():
    if session.attributes['state']==0:
        ask_msg = "OK! Do you want a recommended pizza or create your own?"
        return question(ask_msg)
    elif session.attributes['state']==1:
        if session.attributes['discount']!=0:
            msg = "Perfect! The price is 10 dollars. With the discount, you only have to pay {} dollars. Do you want me to place the order?".format(int((1-session.attributes['discount']/100)*10))
        else:
            msg = "Perfect! The price is 10 dollors. Do you want me to place the order?"
        session.attributes['state']=2
        return question(msg)
    elif session.attributes['state']==2:
        msg = "OK! Your pizza will be ready in ten minutes. Do you want to order one more pizza?"
        session.attributes['state']=0
        session.attributes['discount']=0
        return question(msg)


@ask.intent("NoIntent")
def response_no():
    if session.attributes['state']==0:
        msg = "Sure! Thanks for coming. Have a good day!"
        return statement(msg)
    elif session.attributes['state']==1:
        session.attributes['discount']+=10
        if session.attributes['discount']>=90:
            session.attributes['discount']=90
        if session.attributes['pizza']=='customized pizza':
            msg = "Oh no! Sorry for your bad experience and we will give you a {} percent discount. Let's do it again. What kind of toppings would you like? We have Mushrooms, Sausage and Onions.".format(session.attributes['discount'])
        else:
            msg = "Oh no! Sorry for your bad experience and we will give you a {} percent discount. Let's do it again. We have Supreme Pizza, Meat Lover's Pizza and Pepperoni Pizza. Which one do you want?".format(session.attributes['discount'])
        session.attributes['state']=0
        return question(msg)
        #msg = "Sorry for that! Let's do it again. Do you want a recommended pizza or create your own?"
        #return question(msg)
    elif session.attributes['state']==2:
        msg = "OK! Please say yes to order again or you can say no to leave this system"
        session.attributes['state']=0
        return question(msg)

@ask.intent("NewOrderIntent")
def new_order():
    ask_msg = "OK! Do you want a recommended pizza or create your own?"
    return question(ask_msg)

@ask.intent("RecomndIntent")
def recomnd_order():
    msg = "Sure! We have Supreme Pizza, Meat Lover's Pizza and Pepperoni Pizza. Which one do you want? You can also say customize to create your own."
    return question(msg)

@ask.intent("RecomndChooseIntent")
def ask_size(pizza):
    #record pizza's name
    session.attributes['pizza'] = pizza
    session.attributes['toppings'] = None
    msg = "OK! What size would you like? Small for 10 inches, Medium for 12 inches or Large for 14 inches?"
    return question(msg)

@ask.intent("ToppingIntent")
def create_order():
    msg = "Sure! We have Mushrooms, Sausage and Onions. What toppings would you like?"
    return question(msg)

@ask.intent("ToppingChooseIntent")
def topping_choose(First,Second,Third,Forth):
    session.attributes['pizza'] = 'customized pizza'
    if Forth==None:
        if Third==None:
            if Second==None:
                session.attributes['toppings']=[First]
                #session.attributes['toppingcount'] = [1]
            else:
                session.attributes['toppings']=[First,Second]
        else:
            session.attributes['toppings']=[First,Second,Third]
    else:
        session.attributes['toppings']=[First,Second.Third,Forth]
    msg = "No problem! What size would you like? Small for 10 inches, Medium for 12 inches or Large for 14 inches?"
    return question(msg)

@ask.intent("SizeChooseIntent")
def size_choose(size):
    session.attributes['size'] = size
    if session.attributes['pizza']!='customized pizza':
        msg = "Okay! Your have ordered a {} {}. Did I get right?".format(session.attributes['size'], session.attributes['pizza'])
    else:
        msg = "Okay! Your have ordered a {} {}, with toppings:{}. Did I get right?".format(session.attributes['size'], session.attributes['pizza'],session.attributes['toppings'])
    session.attributes['state']=1
    return question(msg)

@ask.intent("AMAZON.StopIntent")
def stop():
    msg = "Okay! See you!"
    return statement(msg)

@ask.intent("AMAZON.FallbackIntent")
def none():
    msg = "Sorry, I didn't get you. Could you please say it again?"
    return question(msg)

if __name__ == '__main__':

    app.run(debug=True)

